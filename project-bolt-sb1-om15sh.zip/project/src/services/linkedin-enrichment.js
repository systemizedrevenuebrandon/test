import axios from 'axios';
import { config } from '../config/api-config.js';
import { logger } from '../utils/logger.js';
import { RateController } from '../utils/rate-control.js';

const rateController = new RateController({
  baseDelay: 10000, // 10 seconds between batches
  maxDelay: 32000,
  maxRetries: 3,
  maxRequestsPerWindow: 1, // Process one batch at a time
  windowSize: 60000
});

function normalizeLinkedInUrl(url) {
  if (!url) throw new Error('URL is required');
  
  try {
    const urlObj = new URL(url);
    let normalized = urlObj.origin + urlObj.pathname.replace(/\/$/, '');
    
    if (!normalized.includes('www.linkedin.com')) {
      normalized = normalized.replace('linkedin.com', 'www.linkedin.com');
    }
    
    return normalized;
  } catch (error) {
    throw new Error(`Invalid LinkedIn URL: ${url}`);
  }
}

export async function getCompanyDataBatch(linkedInUrls) {
  try {
    if (!Array.isArray(linkedInUrls) || linkedInUrls.length === 0) {
      throw new Error('No LinkedIn URLs provided');
    }

    // Split URLs into batches of 25
    const batches = [];
    for (let i = 0; i < linkedInUrls.length; i += 25) {
      batches.push(linkedInUrls.slice(i, i + 25));
    }

    logger.info(`Processing ${linkedInUrls.length} URLs in ${batches.length} batches of up to 25`);

    const results = [];
    for (let i = 0; i < batches.length; i++) {
      const batch = batches[i];
      logger.info(`Processing batch ${i + 1}/${batches.length} (${batch.length} URLs)`);
      
      try {
        const batchResults = await processUrlBatch(batch);
        results.push(...batchResults);
        logger.success(`Batch ${i + 1} complete: ${batchResults.length}/${batch.length} companies processed`);
      } catch (error) {
        logger.error(`Batch ${i + 1} failed: ${error.message}`);
      }
      
      // Wait between batches unless it's the last one
      if (i < batches.length - 1) {
        logger.info('Waiting 10 seconds before next batch...');
        await new Promise(resolve => setTimeout(resolve, 10000));
      }
    }

    return results;
  } catch (error) {
    logger.error('Company data batch processing failed:', error);
    throw error;
  }
}

async function processUrlBatch(urls) {
  const normalizedUrls = urls
    .map(url => {
      try {
        return normalizeLinkedInUrl(url);
      } catch (error) {
        logger.warn(`Invalid URL skipped: ${url}`);
        return null;
      }
    })
    .filter(Boolean);

  if (normalizedUrls.length === 0) {
    return [];
  }

  logger.info(`Sending batch request for ${normalizedUrls.length} URLs`);
  logger.debug('URLs in batch:', normalizedUrls);

  return rateController.enqueue(async () => {
    try {
      const response = await axios.post(
        config.rapidApi.baseUrl,
        { links: normalizedUrls },
        {
          headers: {
            'Content-Type': 'application/json',
            'X-RapidAPI-Key': config.rapidApi.apiKey,
            'X-RapidAPI-Host': config.rapidApi.host
          },
          timeout: 30000
        }
      );

      if (!response.data?.success) {
        throw new Error(`API error: ${response.data?.message || 'Unknown error'}`);
      }

      if (!Array.isArray(response.data.data)) {
        throw new Error('Invalid response format from API');
      }

      // Map response data to match the nested structure
      const results = response.data.data
        .map(item => {
          if (!item?.entry || !item?.data) {
            logger.warn('Invalid item structure in response');
            return null;
          }

          const companyData = item.data;
          if (!companyData.companyId) {
            logger.warn(`No company ID found for ${item.entry}`);
            return null;
          }

          return {
            companyId: companyData.companyId,
            name: companyData.companyName || '',
            industry: companyData.industry || '',
            employeeCount: companyData.employeeCount || 0,
            linkedInUrl: item.entry,
            headquarters: companyData.headquarter ? {
              country: companyData.headquarter.country || '',
              city: companyData.headquarter.city || '',
              region: companyData.headquarter.geographicArea || ''
            } : null,
            website: companyData.websiteUrl || '',
            description: companyData.description || '',
            followerCount: companyData.followerCount || 0
          };
        })
        .filter(Boolean);

      logger.success(`Successfully processed ${results.length}/${normalizedUrls.length} companies in batch`);
      
      if (results.length === 0) {
        logger.warn('No valid results found in batch response');
      }

      return results;
    } catch (error) {
      if (error.response?.data) {
        logger.error('API Error Response:', error.response.data);
      }
      throw error;
    }
  });
}