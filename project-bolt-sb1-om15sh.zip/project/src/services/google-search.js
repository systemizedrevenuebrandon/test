import axios from 'axios';
import { config } from '../config/api-config.js';
import { logger } from '../utils/logger.js';
import { extractDomainFromUrl } from '../utils/url-validator.js';

function generateSearchQueries(website, companyName) {
  // Remove common TLDs and clean company name
  const cleanName = companyName
    .replace(/[.-]/g, ' ')
    .replace(/\binc\b|\bllc\b|\bltd\b|\bcorp\b/gi, '')
    .trim();

  // Generate variations of the company name
  const nameVariations = [
    cleanName,
    cleanName.replace(/\s+/g, ''),
    cleanName.replace(/[^a-zA-Z0-9]/g, ''),
    `"${cleanName}"`, // Exact match
    cleanName.toLowerCase(),
    cleanName.replace(/\s+/g, '-'),
    // Add common company suffixes
    `${cleanName} Inc`,
    `${cleanName} LLC`,
    `${cleanName} Corporation`,
    // Add AI/Bio/Tech variations
    `${cleanName} AI`,
    `${cleanName} Bio`,
    `${cleanName} Tech`,
    `${cleanName} Technologies`,
    `${cleanName} Therapeutics`,
    // Split camelCase
    cleanName.replace(/([a-z])([A-Z])/g, '$1 $2')
  ];

  // Generate search queries
  return [
    // Domain-based searches
    `site:linkedin.com/company ${website}`,
    `site:linkedin.com/company "${extractDomainFromUrl(website)}"`,
    
    // Name-based searches
    ...nameVariations.map(name => `site:linkedin.com/company "${name}"`),
    
    // Combined searches
    ...nameVariations.map(name => `${name} company site:linkedin.com`),
    
    // Industry context
    ...nameVariations.map(name => `${name} startup site:linkedin.com/company`),
    ...nameVariations.map(name => `${name} biotech site:linkedin.com/company`),
    ...nameVariations.map(name => `${name} software site:linkedin.com/company`)
  ];
}

async function searchGoogle(query) {
  try {
    const response = await axios.post(config.serper.baseUrl, {
      q: query,
      gl: 'us',
      hl: 'en',
      api_key: config.serper.apiKey,
      num: 10 // Request more results
    });
    return response.data.organic || [];
  } catch (error) {
    logger.error(`Google search error: ${error.message}`);
    return [];
  }
}

function isValidLinkedInCompanyUrl(url) {
  return url.includes('linkedin.com/company/') && 
         !url.includes('/life') && 
         !url.includes('/posts') && 
         !url.includes('/jobs') &&
         !url.includes('/people') &&
         !url.includes('/school');
}

export async function findLinkedInCompanyPage(website) {
  const domain = extractDomainFromUrl(website);
  const companyName = domain.split('.')[0];
  logger.info(`Searching for LinkedIn page: ${companyName}`);

  // Try all search variations
  const queries = generateSearchQueries(website, companyName);
  
  for (const query of queries) {
    try {
      const results = await searchGoogle(query);
      const match = results.find(result => isValidLinkedInCompanyUrl(result.link));
      
      if (match) {
        const cleanUrl = match.link.split('?')[0].replace(/\/$/, '');
        logger.success(`Found LinkedIn URL with query "${query}": ${cleanUrl}`);
        return cleanUrl;
      }
    } catch (error) {
      logger.warn(`Search failed for query "${query}": ${error.message}`);
      continue;
    }
  }

  logger.warn(`No LinkedIn company page found for ${website} after trying ${queries.length} variations`);
  return null;
}