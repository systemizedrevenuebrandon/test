import { findLinkedInCompanyPage } from './google-search.js';
import { getCompanyDataBatch } from './linkedin-enrichment.js';
import { extractCompanyNameFromUrl } from '../utils/url-validator.js';
import { generateSingleSalesNavUrl } from '../utils/url-generator.js';
import { logger } from '../utils/logger.js';
import { RateController } from '../utils/rate-control.js';

const searchController = new RateController({
  baseDelay: 1000,
  maxDelay: 16000,
  maxRetries: 2,
  maxRequestsPerWindow: 50,
  windowSize: 60000
});

async function findLinkedInPageControlled(website) {
  return searchController.enqueue(async () => {
    try {
      const companyName = extractCompanyNameFromUrl(website);
      logger.info(`Finding LinkedIn page for: ${companyName} (${website})`);
      
      const linkedInUrl = await findLinkedInCompanyPage(website);
      if (linkedInUrl) {
        logger.success(`Found LinkedIn URL for ${companyName}: ${linkedInUrl}`);
        return { website, linkedInUrl };
      }
      
      logger.warn(`No LinkedIn URL found for ${companyName}`);
      throw new Error('LinkedIn page not found');
    } catch (error) {
      logger.error(`Failed to find LinkedIn page for ${website}: ${error.message}`);
      throw error;
    }
  });
}

async function findLinkedInPages(websites) {
  const results = [];
  const failed = [];
  let processedCount = 0;

  const chunks = [];
  for (let i = 0; i < websites.length; i += 5) {
    chunks.push(websites.slice(i, i + 5));
  }

  logger.info(`Processing ${websites.length} websites in ${chunks.length} chunks`);

  for (const [index, chunk] of chunks.entries()) {
    logger.info(`Processing chunk ${index + 1}/${chunks.length} (${chunk.length} websites)`);
    
    const chunkPromises = chunk.map(async (website) => {
      try {
        const result = await findLinkedInPageControlled(website);
        processedCount++;
        logger.info(`Progress: ${processedCount}/${websites.length} websites processed`);
        return result;
      } catch (error) {
        processedCount++;
        failed.push({ website, reason: error.message });
        return null;
      }
    });

    const chunkResults = await Promise.all(chunkPromises);
    const validResults = chunkResults.filter(Boolean);
    results.push(...validResults);
    
    logger.info(
      `Chunk ${index + 1} complete: ${validResults.length}/${chunk.length} LinkedIn pages found ` +
      `(Total found: ${results.length}/${processedCount})`
    );
  }

  return { results, failed };
}

export async function processCompanies(websites) {
  try {
    if (!Array.isArray(websites) || websites.length === 0) {
      throw new Error('Invalid input: websites must be a non-empty array');
    }

    logger.info(`Starting to process ${websites.length} websites`);

    // Step 1: Find LinkedIn pages
    const { results: linkedInPages, failed: initialFailed } = await findLinkedInPages(websites);
    
    logger.info(
      `LinkedIn page search complete:\n` +
      `- Found: ${linkedInPages.length}\n` +
      `- Failed: ${initialFailed.length}\n` +
      `- Success rate: ${((linkedInPages.length / websites.length) * 100).toFixed(1)}%`
    );
    
    if (linkedInPages.length === 0) {
      logger.error('No LinkedIn pages found for any websites');
      return {
        results: [],
        failed: initialFailed.map(f => f.website),
        processedCount: websites.length,
        successCount: 0,
        failureReasons: initialFailed.reduce((acc, f) => {
          acc[f.website] = f.reason;
          return acc;
        }, {})
      };
    }

    // Step 2: Get company data
    const linkedInUrls = linkedInPages.map(p => p.linkedInUrl);
    logger.info(`Sending ${linkedInUrls.length} URLs for enrichment in batches of 25`);
    
    const enrichedCompanies = await getCompanyDataBatch(linkedInUrls);
    
    logger.info(
      `Enrichment complete:\n` +
      `- Successful: ${enrichedCompanies.length}\n` +
      `- Failed: ${linkedInUrls.length - enrichedCompanies.length}\n` +
      `- Success rate: ${((enrichedCompanies.length / linkedInUrls.length) * 100).toFixed(1)}%`
    );

    // Match enriched data back to original websites
    const processedResults = enrichedCompanies.map(company => {
      const original = linkedInPages.find(p => p.linkedInUrl === company.linkedInUrl);
      if (!original) {
        logger.warn(`Could not match enriched data back to original website for ${company.linkedInUrl}`);
        return null;
      }
      return {
        name: company.name,
        website: original.website,
        linkedInUrl: company.linkedInUrl,
        companyId: company.companyId,
        salesNavUrl: generateSingleSalesNavUrl(company.companyId),
        industry: company.industry,
        employeeCount: company.employeeCount
      };
    }).filter(Boolean);

    // Track companies that failed enrichment
    const enrichedUrls = new Set(enrichedCompanies.map(c => c.linkedInUrl));
    const enrichmentFailed = linkedInPages
      .filter(p => !enrichedUrls.has(p.linkedInUrl))
      .map(p => ({ 
        website: p.website, 
        reason: 'Failed to retrieve company data' 
      }));

    // Combine all failures
    const allFailed = [...initialFailed, ...enrichmentFailed];
    const failureReasons = allFailed.reduce((acc, f) => {
      acc[f.website] = f.reason;
      return acc;
    }, {});

    logger.info(
      `Final processing results:\n` +
      `- Input websites: ${websites.length}\n` +
      `- LinkedIn pages found: ${linkedInPages.length}\n` +
      `- Successfully enriched: ${processedResults.length}\n` +
      `- Total failed: ${allFailed.length}\n` +
      `- Overall success rate: ${((processedResults.length / websites.length) * 100).toFixed(1)}%`
    );

    return {
      results: processedResults,
      failed: allFailed.map(f => f.website),
      processedCount: websites.length,
      successCount: processedResults.length,
      failureReasons
    };

  } catch (error) {
    logger.error('Fatal error in company processing:', error);
    return {
      results: [],
      failed: websites,
      processedCount: websites.length,
      successCount: 0,
      failureReasons: websites.reduce((acc, w) => ({ ...acc, [w]: error.message }), {})
    };
  }
}