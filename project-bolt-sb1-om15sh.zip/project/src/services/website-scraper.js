import axios from 'axios';
import { logger } from '../utils/logger.js';

export async function fetchWebsiteContent(url) {
  try {
    if (!url.startsWith('http')) {
      url = `https://${url}`;
    }
    
    const response = await axios.get(url, {
      timeout: 10000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });
    
    return response.data;
  } catch (error) {
    throw new Error(`Failed to fetch website: ${error.message}`);
  }
}