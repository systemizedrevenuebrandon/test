import { findLinkedInCompanyPage } from './services/google-search.js';
import { getCompanyData } from './services/linkedin-enrichment.js';
import { extractCompanyNameFromUrl } from './utils/url-validator.js';
import { generateBatchSalesNavUrls, generateSingleSalesNavUrl } from './utils/url-generator.js';
import { readWebsitesFromFile } from './utils/file-handler.js';
import { validateInputs, normalizeWebsites } from './utils/validation.js';
import { logger } from './utils/logger.js';

async function processCompany(website) {
  try {
    const companyName = extractCompanyNameFromUrl(website);
    logger.info(`Processing: ${companyName}`);
    
    const linkedInUrl = await findLinkedInCompanyPage(companyName);
    if (!linkedInUrl) {
      logger.error(`No LinkedIn page found for ${companyName}`);
      return null;
    }
    logger.success(`Found LinkedIn URL: ${linkedInUrl}`);

    const companyData = await getCompanyData(linkedInUrl);
    if (!companyData) {
      logger.error(`Could not retrieve company data for ${linkedInUrl}`);
      return null;
    }

    const salesNavUrl = generateSingleSalesNavUrl(companyData.companyId);
    logger.success(`Generated Sales Navigator URL: ${salesNavUrl}`);

    return {
      companyName,
      linkedInUrl,
      ...companyData,
      salesNavUrl
    };
  } catch (error) {
    logger.error(`Error processing ${website}: ${error.message}`);
    return null;
  }
}

async function main() {
  const inputFile = process.argv[2] || 'example-websites.txt';
  const customTitles = process.argv[3] ? process.argv[3].split(',') : undefined;
  
  let websites = await readWebsitesFromFile(inputFile);
  if (websites.length === 0) {
    logger.error('No websites found. Please provide a file with website domains');
    logger.info('Example usage: npm start -- websites.txt "CEO,Founder,CTO"');
    logger.info('Using example-websites.txt as a demo...');
    websites = await readWebsitesFromFile('example-websites.txt');
  }

  if (!validateInputs(websites)) {
    process.exit(1);
  }

  websites = normalizeWebsites(websites);
  logger.info(`Starting to process ${websites.length} websites...\n`);
  
  const results = [];
  for (const website of websites) {
    const result = await processCompany(website);
    results.push(result);
  }

  const successfulResults = results.filter(Boolean);
  logger.info(`\nProcessing complete! Success rate: ${successfulResults.length}/${websites.length}`);

  if (successfulResults.length > 0) {
    console.log('\nDetailed Results:');
    successfulResults.forEach(result => {
      console.log('\n----------------------------------------');
      console.log(`Company: ${result.name}`);
      console.log(`Industry: ${result.industry}`);
      console.log(`Employees: ${result.employeeCount}`);
      console.log(`LinkedIn: ${result.linkedInUrl}`);
      console.log(`Sales Nav: ${result.salesNavUrl}`);
    });

    const companyIds = successfulResults.map(result => result.companyId);
    const batchUrls = generateBatchSalesNavUrls(companyIds, customTitles);
    
    console.log('\nBatch Sales Navigator Search URLs:');
    batchUrls.forEach((url, index) => {
      console.log(`\nBatch ${index + 1}:`);
      console.log(url);
    });
  }
}

main().catch(error => {
  logger.error('Fatal error:', error.message);
  process.exit(1);
});