import React, { useState, useCallback } from 'react';
import { toast, Toaster } from 'react-hot-toast';
import { CompanyResults } from './components/CompanyResults';
import { LoadingSpinner } from './components/LoadingSpinner';

export default function App() {
  const [websites, setWebsites] = useState('');
  const [titles, setTitles] = useState('CEO, Founder, CTO');
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);

  const processCompanies = useCallback(async () => {
    const websiteList = websites
      .split(/[\n,]/)
      .map(site => site.trim())
      .filter(site => site && !site.startsWith('#'));

    if (websiteList.length === 0) {
      throw new Error('Please enter at least one valid website');
    }

    const titleList = titles
      .split(',')
      .map(title => title.trim())
      .filter(Boolean);

    const response = await fetch('/api/process', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        websites: websiteList,
        titles: titleList
      })
    });

    const data = await response.json();

    if (!response.ok || !data.success) {
      throw new Error(data.error || 'Failed to process companies');
    }

    return data;
  }, [websites, titles]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const data = await processCompanies();
      setResults(data);
      toast.success(`Successfully processed ${data.successCount}/${data.processedCount} companies`);
    } catch (error) {
      toast.error(error.message);
      setResults(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">LinkedIn Company Finder</h1>
          <p className="mt-2 text-gray-600">
            Enter company websites to find their LinkedIn pages and generate Sales Navigator URLs
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8 bg-white p-6 rounded-lg shadow">
          <div>
            <label htmlFor="websites" className="block text-sm font-medium text-gray-700">
              Websites
            </label>
            <div className="mt-1">
              <textarea
                id="websites"
                name="websites"
                rows={10}
                className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                placeholder="Enter websites (one per line or comma-separated)"
                value={websites}
                onChange={(e) => setWebsites(e.target.value)}
              />
            </div>
          </div>

          <div>
            <label htmlFor="titles" className="block text-sm font-medium text-gray-700">
              Job Titles
            </label>
            <div className="mt-1">
              <input
                type="text"
                id="titles"
                name="titles"
                className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                placeholder="Enter job titles (comma-separated)"
                value={titles}
                onChange={(e) => setTitles(e.target.value)}
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
          >
            {loading ? <LoadingSpinner /> : 'Generate URLs'}
          </button>
        </form>

        {results && <CompanyResults results={results} />}
        <Toaster position="top-right" />
      </div>
    </div>
  );
}