import React from 'react';

export function InputList({ title, items, setItems, placeholder }) {
  const handleChange = (e) => {
    const value = e.target.value;
    // Split by commas, trim whitespace, and filter out empty items
    const newItems = value
      .split(',')
      .map(item => item.trim())
      .filter(Boolean);
    setItems(newItems);
  };

  // Join items with commas for display
  const displayValue = items.join(', ');

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">{title}</h2>
      <div className="mb-2">
        <textarea
          value={displayValue}
          onChange={handleChange}
          placeholder={`${placeholder} (comma-separated)`}
          className="w-full rounded border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 min-h-[100px]"
        />
      </div>
      <p className="text-sm text-gray-500">
        Enter multiple {title.toLowerCase()} separated by commas
      </p>
    </div>
  );
}