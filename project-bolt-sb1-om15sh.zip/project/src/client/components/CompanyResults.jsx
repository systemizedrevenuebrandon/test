import React from 'react';

export function CompanyResults({ results }) {
  const successCount = results.successCount;
  const failedCount = results.processedCount - results.successCount;
  const successRate = ((successCount / results.processedCount) * 100).toFixed(1);

  return (
    <div className="mt-8 bg-white p-6 rounded-lg shadow">
      <div className="mb-6">
        <h2 className="text-xl font-semibold mb-2">Processing Statistics</h2>
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <p className="text-sm text-gray-600">Total Processed</p>
            <p className="text-2xl font-bold text-gray-900">{results.processedCount}</p>
          </div>
          <div className="bg-green-50 p-4 rounded-lg">
            <p className="text-sm text-green-600">Successfully Found</p>
            <p className="text-2xl font-bold text-green-700">{successCount}</p>
          </div>
          <div className="bg-red-50 p-4 rounded-lg">
            <p className="text-sm text-red-600">Not Found</p>
            <p className="text-2xl font-bold text-red-700">{failedCount}</p>
          </div>
        </div>
        <p className="mt-2 text-sm text-gray-600">Success Rate: {successRate}%</p>
      </div>

      <h2 className="text-xl font-semibold mb-4">Company Details</h2>
      <div className="space-y-6">
        {results.results.map((result, index) => (
          <div key={index} className="border-b pb-4">
            <h3 className="font-medium">{result.name}</h3>
            <p className="text-sm text-gray-600">Industry: {result.industry}</p>
            <p className="text-sm text-gray-600">Employees: {result.employeeCount}</p>
            <div className="mt-2 space-y-1">
              <a href={result.linkedInUrl} target="_blank" rel="noopener noreferrer" 
                 className="text-sm text-blue-600 hover:text-blue-800 block">
                LinkedIn Page
              </a>
              <a href={result.salesNavUrl} target="_blank" rel="noopener noreferrer"
                 className="text-sm text-blue-600 hover:text-blue-800 block">
                Sales Navigator Page
              </a>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6">
        <h3 className="font-medium mb-2">Batch Sales Navigator URLs</h3>
        {results.batchUrls.map((url, index) => (
          <div key={index} className="mb-2">
            <a href={url} target="_blank" rel="noopener noreferrer"
               className="text-sm text-blue-600 hover:text-blue-800">
              Batch {index + 1} Search URL ({index * 80 + 1}-{Math.min((index + 1) * 80, results.results.length)} companies)
            </a>
          </div>
        ))}
      </div>
    </div>
  );
}