import dotenv from 'dotenv';
dotenv.config();

export const config = {
  serper: {
    apiKey: process.env.SERPER_API_KEY,
    baseUrl: 'https://google.serper.dev/search'
  },
  rapidApi: {
    apiKey: process.env.RAPID_API_KEY,
    baseUrl: 'https://linkedin-bulk-data-scraper.p.rapidapi.com/companies',
    host: 'linkedin-bulk-data-scraper.p.rapidapi.com'
  },
  salesNavigator: {
    baseUrl: 'https://www.linkedin.com/sales/company/',
    searchBaseUrl: 'https://www.linkedin.com/sales/search/people',
    defaultTitles: [
      'CEO',
      'Founder',
      'Owner',
      'Co-founder',
      'Partner',
      'Board Member'
    ]
  }
};