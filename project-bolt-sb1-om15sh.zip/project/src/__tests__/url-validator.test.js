import { expect, test } from 'vitest';
import { isValidUrl, extractCompanyNameFromUrl } from '../utils/url-validator.js';

test('isValidUrl validates URLs correctly', () => {
  expect(isValidUrl('https://example.com')).toBe(true);
  expect(isValidUrl('not-a-url')).toBe(false);
});

test('extractCompanyNameFromUrl extracts company names correctly', () => {
  expect(extractCompanyNameFromUrl('https://microsoft.com')).toBe('microsoft');
  expect(extractCompanyNameFromUrl('invalid-url')).toBe('invalid-url');
});