import fs from 'fs/promises';
import { logger } from './logger.js';

export async function readWebsitesFromFile(filePath) {
  try {
    const content = await fs.readFile(filePath, 'utf8');
    const websites = content
      .split('\n')
      .map(line => line.trim())
      .filter(line => line && !line.startsWith('#')); // Skip empty lines and comments
    
    logger.success(`Successfully loaded ${websites.length} websites from file`);
    return websites;
  } catch (error) {
    logger.error(`Error reading websites file: ${error.message}`);
    return [];
  }
}