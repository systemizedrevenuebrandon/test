export function isValidUrl(url) {
  try {
    new URL(url.startsWith('http') ? url : `https://${url}`);
    return true;
  } catch {
    return false;
  }
}

export function extractCompanyNameFromUrl(url) {
  try {
    const domain = extractDomainFromUrl(url);
    return domain.split('.')[0];
  } catch {
    return url;
  }
}

export function extractDomainFromUrl(url) {
  try {
    const urlObj = new URL(url.startsWith('http') ? url : `https://${url}`);
    return urlObj.hostname;
  } catch {
    return url;
  }
}