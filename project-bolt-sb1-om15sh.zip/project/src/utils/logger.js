import chalk from 'chalk';

const timestamp = () => new Date().toISOString();

export const logger = {
  info: (message) => console.log(chalk.blue('ℹ'), `[${timestamp()}] INFO:`, message),
  success: (message) => console.log(chalk.green('✓'), `[${timestamp()}] SUCCESS:`, message),
  error: (message, error) => {
    console.log(chalk.red('✗'), `[${timestamp()}] ERROR:`, message);
    if (error?.response?.data) {
      console.log(chalk.red('  Response:'), JSON.stringify(error.response.data, null, 2));
    }
  },
  warn: (message) => console.log(chalk.yellow('⚠'), `[${timestamp()}] WARNING:`, message),
  debug: (message, data) => {
    if (process.env.DEBUG) {
      console.log(chalk.gray('🔍'), `[${timestamp()}] DEBUG:`, message);
      if (data) console.log(chalk.gray(JSON.stringify(data, null, 2)));
    }
  }
};