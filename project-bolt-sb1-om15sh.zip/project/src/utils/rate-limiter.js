import { logger } from './logger.js';

class RateLimiter {
  constructor(maxConcurrent = 25) {
    this.queue = [];
    this.active = 0;
    this.maxConcurrent = maxConcurrent;
    this.processing = false;
  }

  async execute(fn) {
    return new Promise((resolve, reject) => {
      this.queue.push({ fn, resolve, reject });
      this.processQueue();
    });
  }

  async processQueue() {
    if (this.processing || this.active >= this.maxConcurrent || this.queue.length === 0) return;

    this.processing = true;
    const { fn, resolve, reject } = this.queue.shift();
    this.active++;

    try {
      const result = await fn();
      resolve(result);
    } catch (error) {
      if (error.response?.status === 429) {
        logger.warn('Rate limit hit, retrying after delay...');
        this.queue.unshift({ fn, resolve, reject });
        await new Promise(resolve => setTimeout(resolve, 2000));
      } else {
        reject(error);
      }
    } finally {
      this.active--;
      this.processing = false;
      setTimeout(() => this.processQueue(), 100);
    }
  }
}

// No rate limit for Serper
export const serperLimiter = new RateLimiter(100);
// RapidAPI limits: 25 concurrent requests
export const linkedInLimiter = new RateLimiter(25);