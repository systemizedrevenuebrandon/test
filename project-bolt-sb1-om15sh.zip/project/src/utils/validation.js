import { isValidUrl, extractCompanyNameFromUrl } from './url-validator.js';
import { logger } from './logger.js';

export function validateInputs(websites) {
  if (!Array.isArray(websites) || websites.length === 0) {
    logger.error('No valid websites provided');
    return false;
  }

  const invalidUrls = websites.filter(url => !isValidUrl(url) && !url.includes('.'));
  if (invalidUrls.length > 0) {
    logger.warn(`Found ${invalidUrls.length} potentially invalid websites:`);
    invalidUrls.forEach(url => logger.warn(`  - ${url}`));
  }

  return true;
}

export function normalizeWebsites(websites) {
  return websites.map(website => {
    if (!website.startsWith('http')) {
      website = `https://${website}`;
    }
    return website;
  });
}