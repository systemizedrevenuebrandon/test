import { logger } from './logger.js';

// Utility to add jitter to delays
const addJitter = (delay) => {
  const jitter = Math.random() * 1000 - 500; // ±500ms
  return Math.max(0, delay + jitter);
};

export class RateController {
  constructor(options = {}) {
    this.baseDelay = options.baseDelay || 2000;
    this.maxDelay = options.maxDelay || 32000;
    this.maxRetries = options.maxRetries || 3;
    this.queue = [];
    this.processing = false;
    this.lastRequestTime = 0;
    this.windowStart = Date.now();
    this.requestsInWindow = 0;
    this.maxRequestsPerWindow = options.maxRequestsPerWindow || 25;
    this.windowSize = options.windowSize || 60000; // 1 minute
  }

  async enqueue(operation) {
    return new Promise((resolve, reject) => {
      this.queue.push({
        operation,
        resolve,
        reject,
        attempts: 0,
        id: Math.random().toString(36).substr(2, 9)
      });
      
      if (!this.processing) {
        this.processQueue();
      }
    });
  }

  async processQueue() {
    if (this.processing || this.queue.length === 0) {
      return;
    }

    this.processing = true;
    const item = this.queue[0];

    try {
      await this.enforceRateLimit();
      const result = await this.executeWithRetry(item);
      this.queue.shift();
      item.resolve(result);
    } catch (error) {
      this.queue.shift();
      item.reject(error);
    } finally {
      this.processing = false;
      if (this.queue.length > 0) {
        setTimeout(() => this.processQueue(), this.baseDelay);
      }
    }
  }

  async enforceRateLimit() {
    const now = Date.now();
    
    // Reset window if needed
    if (now - this.windowStart > this.windowSize) {
      this.windowStart = now;
      this.requestsInWindow = 0;
    }

    // Check if we're at the limit
    if (this.requestsInWindow >= this.maxRequestsPerWindow) {
      const waitTime = this.windowSize - (now - this.windowStart);
      logger.warn(`Rate limit reached, waiting ${waitTime}ms for next window`);
      await new Promise(resolve => setTimeout(resolve, waitTime));
      this.windowStart = Date.now();
      this.requestsInWindow = 0;
    }

    // Ensure minimum delay between requests
    const timeSinceLastRequest = now - this.lastRequestTime;
    if (timeSinceLastRequest < this.baseDelay) {
      const waitTime = addJitter(this.baseDelay - timeSinceLastRequest);
      await new Promise(resolve => setTimeout(resolve, waitTime));
    }

    this.lastRequestTime = Date.now();
    this.requestsInWindow++;
  }

  async executeWithRetry(item) {
    let delay = this.baseDelay;
    
    while (item.attempts < this.maxRetries) {
      try {
        return await item.operation();
      } catch (error) {
        item.attempts++;
        
        if (error.response?.status === 429 && item.attempts < this.maxRetries) {
          delay = Math.min(delay * 2, this.maxDelay);
          const waitTime = addJitter(delay);
          
          logger.warn(
            `Rate limit hit (attempt ${item.attempts}/${this.maxRetries}), ` +
            `waiting ${Math.round(waitTime/1000)}s...`
          );
          
          await new Promise(resolve => setTimeout(resolve, waitTime));
          continue;
        }
        
        throw error;
      }
    }
  }
}