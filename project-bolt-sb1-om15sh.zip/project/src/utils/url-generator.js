import { logger } from './logger.js';
import { config } from '../config/api-config.js';

const BATCH_SIZE = 80; // Maximum companies per Sales Navigator URL
const SEARCH_QUERY_PREFIX = '?query=(filters%3AList(';
const SEARCH_QUERY_SUFFIX = '))&viewAllFilters=true';

function chunkArray(array, size) {
  const chunks = [];
  for (let i = 0; i < array.length; i += size) {
    chunks.push(array.slice(i, i + size));
  }
  return chunks;
}

function formatCompanyIdForUrl(companyId) {
  return `(id%3Aurn%253Ali%253Aorganization%253A${companyId}%2CselectionType%3AINCLUDED)`;
}

function formatTitleForUrl(title) {
  return `(text%3A${encodeURIComponent(title.trim())}%2CselectionType%3AINCLUDED)`;
}

function generateTitleFilter(titles) {
  if (!titles || !titles.length) {
    return '';
  }
  const titleValues = titles.map(formatTitleForUrl).join('%2C');
  return `(type%3ACURRENT_TITLE%2Cvalues%3AList(${titleValues}))`;
}

function generateCompanyFilter(companyIds) {
  const companyValues = companyIds.map(formatCompanyIdForUrl).join('%2C');
  return `(type%3ACURRENT_COMPANY%2Cvalues%3AList(${companyValues}))`;
}

export function generateBatchSalesNavUrls(companyIds, titles = []) {
  try {
    if (!Array.isArray(companyIds) || companyIds.length === 0) {
      logger.warn('No company IDs provided for batch URL generation');
      return [];
    }

    const batches = chunkArray(companyIds, BATCH_SIZE);
    logger.info(`Creating ${batches.length} batch URLs (max ${BATCH_SIZE} companies per URL)`);

    return batches.map((batch, index) => {
      const filters = [
        generateCompanyFilter(batch),
        generateTitleFilter(titles)
      ].filter(Boolean).join('%2C');

      const url = `${config.salesNavigator.searchBaseUrl}${SEARCH_QUERY_PREFIX}${filters}${SEARCH_QUERY_SUFFIX}`;
      logger.success(`Generated batch URL ${index + 1}/${batches.length}`);
      return url;
    });
  } catch (error) {
    logger.error(`Failed to generate batch URLs: ${error.message}`);
    return [];
  }
}

export function generateSingleSalesNavUrl(companyId) {
  if (!companyId) {
    logger.warn('No company ID provided for single URL generation');
    return null;
  }
  return `${config.salesNavigator.baseUrl}${companyId}`;
}