import express from 'express';
import cors from 'cors';
import { processCompanies } from '../services/company-processor.js';
import { generateBatchSalesNavUrls } from '../utils/url-generator.js';
import { logger } from '../utils/logger.js';
import { normalizeWebsites } from '../utils/validation.js';

const app = express();

app.use(cors());
app.use(express.json());

app.post('/api/process', async (req, res) => {
  try {
    const { websites, titles } = req.body;
    
    if (!websites || !Array.isArray(websites) || websites.length === 0) {
      return res.status(400).json({ 
        error: 'No websites provided',
        success: false 
      });
    }

    const normalizedWebsites = normalizeWebsites(websites);
    logger.info(`Processing ${normalizedWebsites.length} websites in batches of 25`);

    const results = await processCompanies(normalizedWebsites);
    const companyIds = results.map(result => result.companyId).filter(Boolean);
    const batchUrls = generateBatchSalesNavUrls(companyIds, titles);

    res.json({ 
      success: true,
      results,
      batchUrls,
      processedCount: normalizedWebsites.length,
      successCount: results.length
    });
  } catch (error) {
    logger.error('API Error:', error.message);
    res.status(500).json({ 
      error: error.message,
      success: false 
    });
  }
});

app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

const port = 3002;
app.listen(port, () => {
  logger.success(`Server running on port ${port}`);
});